<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="tileset" tilewidth="16" tileheight="16" tilecount="11" columns="11">
 <image source="tileset.png" trans="003039" width="176" height="16"/>
</tileset>
